import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

public class FileIO {

    private final static String inputFileName = "colors.txt";
    private final static String outputFileName = "outcome.txt";

    public String readSettingFile() {
        //System.out.println("Working Directory = " + System.getProperty("user.dir"));
        StringBuilder resultStringBuilder = new StringBuilder();
        if(inputFileName != null) {
            try (BufferedReader br
                         = new BufferedReader(new FileReader(inputFileName))) {
                String line;
                while ((line = br.readLine()) != null) {
                    resultStringBuilder.append(line).append("\n");
                }
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
        return resultStringBuilder.toString().trim();
    }

    public void writeToFile(String data) {
        try{
            Path file = Paths.get(outputFileName);
            Files.write(file, Arrays.asList(data), Charset.forName("UTF-8"));
            System.out.println("Game result saved in file : " + outputFileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

