import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Scanner;

public class Input {

    public static int takeUserInputInteger() {
        Scanner scanner = new Scanner(System.in);
        String userInput = scanner.next().toUpperCase();

        int num = 0;
        do {
            try{
                num = Integer.parseInt(userInput);
                if( num < 0) System.out.println("Please enter a valid positive Integer.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid Number! Please enter a valid Integer.");
            }
            System.out.println();
        } while (num <= 0);

        return num;
    }

    public static String takeUserInput() {
        Scanner scanner = new Scanner(System.in);
        String userInput = scanner.next().toUpperCase();
        System.out.println();
        return userInput;
    }

    public static void takeAnyKey() {
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();

    }
}
